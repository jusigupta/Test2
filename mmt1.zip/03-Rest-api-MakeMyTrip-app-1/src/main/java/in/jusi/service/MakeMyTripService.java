package in.jusi.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import in.jusi.binding.Passenger;
import in.jusi.binding.Ticket;

@Service
public class MakeMyTripService {
	
	public Ticket bookticket(Passenger p) {
		
		String apiUrl= "http://localhost:8080/getTickets";

		RestTemplate rt = new RestTemplate(); // to https request to the url
		ResponseEntity<Ticket> forEntity = rt.postForEntity(apiUrl, p, Ticket.class); // apiurl- to which url  you want to send post request , p (request/passenger object)-what data you send in request body , Ticket.class- what response  you are expecting from the provider
		
		Ticket body = forEntity.getBody(); // want get response entity 
		return body;
	}
	
	public List<Ticket> getAllTickets(){
String apiUrl= "http://localhost:8080/tickets";
		
		RestTemplate rt = new RestTemplate();
		ResponseEntity<Ticket[]> forEntity = rt.getForEntity(apiUrl, Ticket[].class);
		Ticket[] body = forEntity.getBody();
		List<Ticket> tickets = Arrays.asList(body);
		return tickets;
		
	}

}
