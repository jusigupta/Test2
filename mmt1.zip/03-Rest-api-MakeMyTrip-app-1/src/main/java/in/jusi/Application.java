package in.jusi;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.jusi.binding.Ticket;
import in.jusi.service.MakeMyTripService;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
		MakeMyTripService bean = context.getBean(MakeMyTripService.class);
		List<Ticket> allTickets = bean.getAllTickets();
		allTickets.forEach(System.out::println);
	}

}
